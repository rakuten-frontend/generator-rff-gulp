'use strict';

var $ = require('jquery');

$(function () {
  console.log('Hello!');
});
